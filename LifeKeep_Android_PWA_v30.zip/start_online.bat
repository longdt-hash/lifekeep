@echo off
chcp 65001 >nul
title LifeKeep - Máy chủ Online Toàn cầu (4G / 5G / Wi-Fi)
echo ========================================================
echo   LifeKeep PWA - Khởi chạy Online Toàn Cầu
echo ========================================================
echo.
echo Đang khởi chạy máy chủ cục bộ (Port 8080)...
start /b powershell -ExecutionPolicy Bypass -File "%~dp0server.ps1"
timeout /t 2 >nul
echo.
echo Đang mở đường truyền bảo mật Cloudflare Tunnel (HTTPS)...
"%~dp0cloudflared.exe" tunnel --url http://127.0.0.1:8080
pause
