@echo off
title LifeKeep Server
cd /d "%~dp0"
powershell -ExecutionPolicy Bypass -File server.ps1
pause
