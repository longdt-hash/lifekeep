# LifeKeep High-Performance Local Web Server
# Robust non-blocking TCP server for Windows

$port = 8080
$rootPath = $PSScriptRoot
if (-not $rootPath) { $rootPath = Get-Location }

# Discover local network IPs reliably without requiring elevated admin permissions
$localIPs = @()
try {
    $nics = [System.Net.NetworkInformation.NetworkInterface]::GetAllNetworkInterfaces() | Where-Object { 
        $_.OperationalStatus -eq 'Up' -and 
        $_.NetworkInterfaceType -ne 'Loopback' -and 
        $_.Description -notlike '*VPN*' -and 
        $_.Description -notlike '*WARP*' -and 
        $_.Description -notlike '*Virtual*' 
    }
    foreach ($nic in $nics) {
        foreach ($addr in $nic.GetIPProperties().UnicastAddresses) {
            if ($addr.Address.AddressFamily -eq 'InterNetwork') {
                $localIPs += [PSCustomObject]@{
                    Name = $nic.Name
                    IP = $addr.Address.IPAddressToString
                }
            }
        }
    }
} catch {}

if ($localIPs.Count -eq 0) {
    $localIPs += [PSCustomObject]@{ Name = "Local"; IP = "localhost" }
}

$listener = [System.Net.Sockets.TcpListener]::Create($port)

try {
    $listener.Start()
} catch {
    Write-Host "Loi khoi dong cong: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}

Write-Host "==========================================================" -ForegroundColor Cyan
Write-Host "LifeKeep App dang chay on dinh (Theme Tim Neobank v12)!" -ForegroundColor Green
Write-Host "----------------------------------------------------------" -ForegroundColor DarkGray
Write-Host "May tinh: http://localhost:$port" -ForegroundColor Yellow
foreach ($ipObj in $localIPs) {
    Write-Host "Dien thoai ($($ipObj.Name)): http://$($ipObj.IP):$port" -ForegroundColor Green
}
Write-Host "==========================================================" -ForegroundColor Cyan

$mimeTypes = @{
    ".html" = "text/html; charset=utf-8"
    ".htm"  = "text/html; charset=utf-8"
    ".js"   = "application/javascript; charset=utf-8"
    ".json" = "application/json; charset=utf-8"
    ".css"  = "text/css; charset=utf-8"
    ".svg"  = "image/svg+xml"
    ".png"  = "image/png"
    ".jpg"  = "image/jpeg"
    ".jpeg" = "image/jpeg"
    ".ico"  = "image/x-icon"
}

$CRLF = [string][char]13 + [string][char]10

try {
    while ($true) {
        if (-not $listener.Pending()) {
            Start-Sleep -Milliseconds 15
            continue
        }

        $client = $listener.AcceptTcpClient()
        $client.ReceiveTimeout = 1500
        $client.SendTimeout = 1500

        try {
            $stream = $client.GetStream()
            $buffer = New-Object byte[] 4096
            $bytesRead = $stream.Read($buffer, 0, $buffer.Length)

            if ($bytesRead -gt 0) {
                $requestText = [System.Text.Encoding]::UTF8.GetString($buffer, 0, $bytesRead)
                $firstLine = $requestText.Split("`n")[0].Trim()
                $parts = $firstLine.Split(" ")

                if ($parts.Length -ge 2) {
                    $urlPath = $parts[1].Split("?")[0]

                    if ($urlPath -eq "/" -or $urlPath -eq "") {
                        $urlPath = "/index.html"
                    }

                    $filePath = Join-Path $rootPath $urlPath.TrimStart('/')
                    $filePath = [System.IO.Path]::GetFullPath($filePath)

                    if ($filePath.StartsWith($rootPath) -and (Test-Path $filePath -PathType Leaf)) {
                        $ext = [System.IO.Path]::GetExtension($filePath).ToLower()
                        $contentType = $mimeTypes[$ext]
                        if (-not $contentType) { $contentType = "application/octet-stream" }

                        $fileBytes = [System.IO.File]::ReadAllBytes($filePath)
                        $header = "HTTP/1.1 200 OK" + $CRLF + "Content-Type: " + $contentType + $CRLF + "Content-Length: " + $fileBytes.Length + $CRLF + "Cache-Control: no-cache, no-store, must-revalidate" + $CRLF + "Pragma: no-cache" + $CRLF + "Access-Control-Allow-Origin: *" + $CRLF + "Connection: close" + $CRLF + $CRLF
                        $headerBytes = [System.Text.Encoding]::UTF8.GetBytes($header)

                        $stream.Write($headerBytes, 0, $headerBytes.Length)
                        $stream.Write($fileBytes, 0, $fileBytes.Length)
                        $stream.Flush()
                    } else {
                        $notFound = "HTTP/1.1 404 Not Found" + $CRLF + "Content-Type: text/plain" + $CRLF + "Content-Length: 9" + $CRLF + "Connection: close" + $CRLF + $CRLF + "Not Found"
                        $notFoundBytes = [System.Text.Encoding]::UTF8.GetBytes($notFound)
                        $stream.Write($notFoundBytes, 0, $notFoundBytes.Length)
                        $stream.Flush()
                    }
                }
            }
        } catch {
            # Ignore transient client disconnect
        } finally {
            if ($stream) { $stream.Close() }
            if ($client) { $client.Close() }
        }
    }
} finally {
    $listener.Stop()
}
